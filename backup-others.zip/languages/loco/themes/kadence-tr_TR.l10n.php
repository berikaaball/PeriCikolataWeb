<?php
return ['project-id-version'=>'Kadence 1.1.48','report-msgid-bugs-to'=>'https://wordpress.org/support/theme/kadence','last-translator'=>'','language-team'=>'Türkçe','mime-version'=>'1.0','content-type'=>'text/plain; charset=UTF-8','content-transfer-encoding'=>'8bit','pot-creation-date'=>'2023-10-18T21:23:50+00:00','po-revision-date'=>'2024-05-15 09:23+0000','x-generator'=>'Loco https://localise.biz/','x-domain'=>'kadence
','language'=>'tr_TR','plural-forms'=>'nplurals=2; plural=n != 1;','x-loco-version'=>'2.6.9; wp-6.5.3','messages'=>[]];
